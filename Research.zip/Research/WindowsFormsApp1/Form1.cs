﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Collections;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-VUOJ1JB;Initial Catalog=Researches;Integrated Security=True"); // Local connection
        SqlCommand cmd;
        SqlDataReader dr;
        Dictionary<string, Person> Researcher = new Dictionary<string, Person>(); // Dictionary of Researchers, the key is the email
        Dictionary<string, string> Research = new Dictionary<string, string>(); // Dictionary of Research, the key is the ID
        Dictionary<int, string> emailByIndex = new Dictionary<int, string>(); // Dictionary of emails, the key is the listbox index
        Dictionary<int, string> IdByIndex = new Dictionary<int, string>(); // Dictionary of ID'S, the key is the listbox index
        ArrayList emailsList=new ArrayList();
        List<int> IdList= new List<int>(); 
        public Form1()
        {
            InitializeComponent();
            this.Text = "Home Page";
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select * from Researcher"; // Get all Researchers
            dr = cmd.ExecuteReader();
            int counter = 0;
            //Loop to retrieve all the details from the query
            while (dr.Read())
            {
                Person temp = new Person();
                temp.Name = dr["Name"].ToString();
                temp.Phone = dr["Phone"].ToString();
                temp.Email = dr["Email"].ToString();
                temp.Description = dr["Description"].ToString();
                temp.Photo = dr["Photo"].ToString();
                listBox1.Items.Add(temp.Name);
                emailByIndex.Add(counter, temp.Email); // Add the email based on the Listbox index
                counter++;
                this.Researcher.Add(temp.Email, temp);
                emailsList.Add(temp.Email);
                  
            }
            con.Close();
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select * from Research"; // Get all the studies
            dr = cmd.ExecuteReader();
            counter = 0;
            while (dr.Read())
            {
                IdByIndex.Add(counter, dr["ID"].ToString()); // Add the ID based on the Listbox index
                counter++;
                listBox2.Items.Add(dr["Name"].ToString());
                this.Research.Add( dr["ID"].ToString(), dr["Name"].ToString());
                IdList.Add(Int32.Parse(dr["ID"].ToString())); // Convert to Int

            }
            con.Close();
        }

        //Redirect to the Researcher edit form based on the selection
        private void listBox1_Click(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedItem != null)
            {
                string Email = this.emailByIndex[this.listBox1.SelectedIndex]; // Get the relevant Email
                var form2 = new Form2(Email, this.Researcher, this.Research); // Create Edit Form
                this.Hide();
                form2.Closed += (s, args) => this.Close();
                form2.StartPosition = FormStartPosition.Manual;
                form2.Location = this.Location;
                form2.Show();
            }
        }

        //Redirect to the add Researcher Form
        private void button1_Click(object sender, EventArgs e)
        {
            var form3 = new Form3(emailsList, this.Research, this.Researcher); // Create add Form
            this.Hide();
            form3.Closed += (s, args) => this.Close();
            form3.StartPosition = FormStartPosition.Manual;
            form3.Location = this.Location;
            form3.Show();
        }

        //Redirect to the Research edit form based on the selection
        private void listBox2_Click(object sender, EventArgs e)
        {
            if (this.listBox2.SelectedItem != null)
            {
                string ID = this.IdByIndex[this.listBox2.SelectedIndex]; // Get the relevant ID
                var form4 = new Form4(this.Research, ID, this.Researcher); // Create the edit form
                this.Hide();
                form4.Closed += (s, args) => this.Close();
                form4.StartPosition = FormStartPosition.Manual;
                form4.Location = this.Location;
                form4.Show();
            }
        }

        //Redirect to the add Research Form
        private void button2_Click(object sender, EventArgs e)
        {
            var form5 = new Form5(this.IdList, this.Research); // Create the add form
            this.Hide();
            form5.Closed += (s, args) => this.Close();
            form5.StartPosition = FormStartPosition.Manual;
            form5.Location = this.Location;
            form5.Show();
        }
    }
}
