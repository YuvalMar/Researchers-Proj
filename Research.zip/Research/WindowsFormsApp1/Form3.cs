﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Windows;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-VUOJ1JB;Initial Catalog=Researches;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        Dictionary<string, string> studiesList = new Dictionary<string, string>(); // Dictionary of the studies, key: ID val: name
        Dictionary<String, Person> researcherList = new Dictionary<String, Person>(); // Dictionary of the Researchers: key: Email val: Person
        Dictionary<int, string> IdByIndex = new Dictionary<int, string>(); // Dictionary for listbox1 key: listboxindex val: name
        private String newpath = "";
        String name;
        String phone;
        String email;
        String description = "";
        String photo = "";
        Boolean flag = false; // Flag that indicates save button was clicked
        ArrayList emails= new ArrayList(); 
        public Form3(ArrayList emailList, Dictionary<string, string> studies, Dictionary<String, Person> Researcher)
        {
            this.emails = emailList;
            this.studiesList = studies;
            this.researcherList = Researcher;
            InitializeComponent();
            // Make all fields editable
            this.textBox1.ReadOnly = false;
            this.textBox2.ReadOnly = false;
            this.textBox3.ReadOnly = false;
            this.richTextBox1.ReadOnly = false;
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select * from  Research "; // Get all the studies details
            dr = cmd.ExecuteReader();
            int counter = 0; // Counter equal to listbox1 index
            // Loop to add the details to the listbox
            while (dr.Read())
            {
                    listBox1.Items.Add(dr["Name"].ToString());
                    this.IdByIndex.Add(counter, dr["ID"].ToString());
                    counter++;
                
            }
            con.Close();
            this.Text = "Add New Researcher"; // Set the form title

        }

        // Upload photo button
        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpeg;*.bmp;*.png;*.jpg)|*.jpeg;*.bmp;*.png;*.jpg"; // Restrict choice to images format only
            if (open.ShowDialog() == DialogResult.OK)
            {
                string newPhoto = open.FileName;
                this.newpath = newPhoto.Replace("\\", "/"); // Flip the backslash 
                this.pictureBox1.ImageLocation = newPhoto;
            }
        }

        // Go back button
        private void button3_Click(object sender, EventArgs e)
        {
            var form1 = new Form1();
            this.Hide();
            form1.Closed += (s, args) => this.Close();
            form1.StartPosition = FormStartPosition.Manual;
            form1.Location = this.Location;
            form1.Show();
        }

        // Save Button
        private void button2_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.Connection = con;
            // Save the fields details 
            name = this.textBox1.Text.ToString();
            phone = this.textBox2.Text.ToString();
            email = this.textBox3.Text.ToString();
            description = this.richTextBox1.Text.ToString();
            if (this.newpath != null)
            {
                photo = this.newpath;
            }
            if (this.emails.Contains(email))
            {
                MessageBox.Show("The Email " + email + " is already used, please choose another one!");
                this.textBox3.Text = email;
            }
            else
            {
                if (email.Length > 0 && name.Length > 0) // Make sure user assigned name and email
                {
                    con.Open();
                    // Insert the values to the DB query
                    cmd.CommandText = "INSERT INTO Researcher(Name, Phone, Email, Description, Photo) VALUES(@name, @phone, @email, @description, @photo)";
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@phone", phone);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@photo", photo);
                    cmd.Parameters.AddWithValue("@description", description);
                    MessageBox.Show("The Researcher " + name + " Was Added!");
                    dr = cmd.ExecuteReader();
                    con.Close();
                    this.flag = true; // Save button was clicked 
                    this.button2.Hide(); // Hide save button

                }
                else
                {
                    MessageBox.Show("You must specify an email and name!");
                }

            }
        }

        // Add research button
        private void button1_Click(object sender, EventArgs e)
        {
            if (flag != false) // If the researcher was already saved
            {

                if (this.listBox1.SelectedItem != null)
                {
                    String selected = this.listBox1.SelectedItem.ToString(); // Get selected research
                    var confirmResult = MessageBox.Show("Are you sure you want to Add " + this.textBox1.Text + " to the research " + selected + " ?",
                                           "Confirm!",
                                           MessageBoxButtons.YesNo);
                    if (confirmResult == System.Windows.Forms.DialogResult.Yes)
                    {
                        string ID = this.IdByIndex[this.listBox1.SelectedIndex]; // Get selected research ID
                        cmd = new SqlCommand();
                        cmd.Connection = con;
                        con.Open();
                        cmd.CommandText = "INSERT INTO Research_Reasearches (ID, Email) VALUES(@ID, @Email)"; // Update DB 
                        cmd.Parameters.AddWithValue("@ID", ID);
                        cmd.Parameters.AddWithValue("@Email", this.textBox3.Text.ToString());
                        dr = cmd.ExecuteReader();
                        con.Close();
                        MessageBox.Show(this.textBox1.Text + " Was Added to the study " + selected + " Successfuly");
                        int selindex = this.listBox1.SelectedIndex; // Get selected research listbox ID
                        this.listBox1.Items.RemoveAt(selindex); // Remove the research from the listbox
                        Dictionary<int, string> temp = new Dictionary<int, string>();
                        this.IdByIndex.Remove(selindex); // Remove the research from the index dictionary
                        // Rebuild the dictionary after removal
                        foreach (int item in this.IdByIndex.Keys)
                        {
                            if (item > selindex)
                            {
                                temp.Add(item-1, this.IdByIndex[item]);
                            }
                            else
                            {
                                temp.Add(item, this.IdByIndex[item]);
                            }

                        }
                        this.IdByIndex = temp;
                    }
                }
            }
            else
            {
                MessageBox.Show("You must save the Researcher First!");
            }
        }

        // Present the relevant research after click
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedItem != null)
            {
                string ID = this.IdByIndex[this.listBox1.SelectedIndex]; // Get the research ID
                var form4 = new Form4(this.studiesList, ID, this.researcherList);
                this.Hide();
                form4.Closed += (s, args) => this.Close();
                form4.StartPosition = FormStartPosition.Manual;
                form4.Location = this.Location;
                form4.Show();
            }
        }
    }
 }
