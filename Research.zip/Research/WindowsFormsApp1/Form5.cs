﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Windows;


namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-VUOJ1JB;Initial Catalog=Researches;Integrated Security=True");
        
        SqlCommand cmd;
        SqlDataReader dr;
        List<int> List = new List<int>(); // List that contain all the ID's
        String id="";
        String description = "";
        String name = "";
        Dictionary<string, Person> Researcher = new Dictionary<string, Person>(); // Dictionary of the Researchers, key: Email val: Person
        Dictionary<int, string> emailByIndex = new Dictionary<int, string>(); // Dictionary for listbox1 key: listboxindex val: email
        Dictionary<string, string> studies = new Dictionary<string, string>(); // Dictionary of the studies, key: ID val: name
        Boolean flag = false; // Flag that indicates save button was pressed
        public Form5(List<int> idList, Dictionary<string, string> studiesList)
        {
            this.List = idList;
            this.studies = studiesList;
            InitializeComponent();
            // Make field editable
            this.textBox1.ReadOnly = false;
            this.textBox3.ReadOnly = false;
            this.richTextBox1.ReadOnly = false;
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select * from Researcher";
            dr = cmd.ExecuteReader();
            int counter = 0; // Counter equal to listbox1 index  
            while (dr.Read())
            {
                Person temp = new Person();
                temp.Name = dr["Name"].ToString();
                temp.Phone = dr["Phone"].ToString();
                temp.Email = dr["Email"].ToString();
                temp.Description = dr["Description"].ToString();
                temp.Photo = dr["Photo"].ToString();
                listBox1.Items.Add(temp.Name);
                emailByIndex.Add(counter, temp.Email); // Dictionary that maps the emails according to listbox index
                counter++;
                this.Researcher.Add(temp.Email, temp);
            }
            con.Close();
            this.Text = "Add New Research"; // Set the form title
        }

        // Save button 
        private void button2_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.Connection = con;
            int i;
            id = this.textBox3.Text;
            if (int.TryParse(id, out i))
            {
                int test = Int32.Parse(this.textBox3.Text); // Parse the ID to integer
                description = this.richTextBox1.Text.ToString();
                name = this.textBox1.Text.ToString();
                if (this.List.Contains(test)) // Check if the ID is already used
                {
                    MessageBox.Show("The ID " + id + " is already used, please choose another one!");
                    this.textBox3.Text = "";
                }
                else
                {
                    if (id.Length > 0 && name.Length > 0) // Check that name and ID are set
                    {
                        con.Open();
                        cmd.CommandText = "INSERT INTO Research(ID, Description, Name) VALUES(@ID, @Description, @Name)"; // Insert into DB query
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@ID", id);
                        cmd.Parameters.AddWithValue("@Description", description);
                        dr = cmd.ExecuteReader();
                        con.Close();
                        MessageBox.Show("The Research " + name + " Was Added! ");
                        // Hide save button and set the fields readonly
                        this.button2.Hide();
                        this.textBox1.ReadOnly = true;
                        this.textBox3.ReadOnly = true;
                        this.richTextBox1.ReadOnly = true;
                        flag = true;

                    }
                    else
                    {
                        MessageBox.Show("You must specify an ID and name!");
                    }
                }
            }
            else
            {
                MessageBox.Show("ID must be a Number!");
            }
              
           }
        
        // Return button
        private void button3_Click(object sender, EventArgs e)
        {
            var form1 = new Form1();
            this.Hide();
            form1.Closed += (s, args) => this.Close();
            form1.StartPosition = FormStartPosition.Manual;
            form1.Location = this.Location;
            form1.Show();
        }

        // Add researcher button
        private void button1_Click(object sender, EventArgs e)
        {
            if (flag != false)
            {

                if (this.listBox1.SelectedItem != null)
                {
                    String selected = this.listBox1.SelectedItem.ToString(); // Get selected researcher
                    var confirmResult = MessageBox.Show("Are you sure you want to Add " + selected + " to the research " + this.textBox1.Text + " ?",
                                           "Confirm!",
                                           MessageBoxButtons.YesNo);
                    if (confirmResult == System.Windows.Forms.DialogResult.Yes)
                    {
                        string Email = this.emailByIndex[this.listBox1.SelectedIndex];
                        cmd = new SqlCommand();
                        cmd.Connection = con;
                        con.Open();
                        cmd.CommandText = "INSERT INTO Research_Reasearches (ID, Email) VALUES(@ID, @Email)";
                        cmd.Parameters.AddWithValue("@Email", Email);
                        cmd.Parameters.AddWithValue("@ID", this.textBox3.Text.ToString());
                        dr = cmd.ExecuteReader();
                        con.Close();
                        MessageBox.Show(selected + " Was Added to the study " + this.textBox1.Text + " Successfuly");
                        int selindex = this.listBox1.SelectedIndex; // Get selected researcher index
                        this.listBox1.Items.RemoveAt(selindex); // Remove selected researcher from listbox1
                        Dictionary<int, string> temp = new Dictionary<int, string>();
                        this.emailByIndex.Remove(selindex);
                        // Loop to rebuild the email by index dictionary 
                        foreach (int item in this.emailByIndex.Keys)
                        {
                            if (item > selindex)
                            {
                                temp.Add(item - 1, this.emailByIndex[item]);
                            }
                            else
                            {
                                temp.Add(item, this.emailByIndex[item]);
                            }
                        }
                        this.emailByIndex = temp;
                        this.button2.Hide();
                    }
                }
            }
            else
            {
                MessageBox.Show("You must save the Research First!");
            }
        }

        // Display the relevant researcher
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedItem != null)
            {
                string Email = this.emailByIndex[this.listBox1.SelectedIndex]; // Get the researcher email
                var form2 = new Form2(Email, this.Researcher, this.studies );
                this.Hide();
                form2.Closed += (s, args) => this.Close();
                form2.StartPosition = FormStartPosition.Manual;
                form2.Location = this.Location;
                form2.Show();
            }
        }
    }
}
