﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Person
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public string Photo { get; set; }

        public Person(string name, string phone, string email, string description, string photo)
        {
            Name = name;
            Phone = phone;
            Email = email;
            Description = description;
            Photo = photo;
        }

        public Person()
        {
        }
    }
}
