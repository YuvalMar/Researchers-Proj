﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Windows;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-VUOJ1JB;Initial Catalog=Researches;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        // Old params in order to save the old details
        String oldname = "";
        String oldphone = "";
        String oldemail = "";
        String oldDescription = "";
        String oldPhoto = "";
        List<String> names = new List<String>(); // List of all the studies names who are linked to the relevant researcher
        Dictionary<string, string> studies = new Dictionary<string, string>(); // Dictionary of the studies, key: ID val: name
        Dictionary<String, Person> Researcher= new Dictionary<String, Person>(); // Dictionary of the Researchers: key: Email val: Person
        Dictionary<int, string> IdByIndex = new Dictionary<int, string>(); // Dictionary for listbox1 key: listboxindex val: name
        Dictionary<int, string> UidByIndex = new Dictionary<int, string>(); // Dictionary for listbox2 key: listboxindex val: name
        public Form2(String Email, Dictionary<String, Person> Researcher , Dictionary<string, string> Research)
        {
            this.Researcher = Researcher;
            this.studies = Research;
            this.oldemail = Email;
            InitializeComponent();
            this.button2.Hide(); // Hide the save button
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            // Query to get all the studies of this researcher
            cmd.CommandText = "select R.Name,R.ID from Researcher as RS INNER JOIN Research_Reasearches as RR  on RR.Email = RS.Email  INNER JOIN Research as R on RR.ID = R.ID Where RS.Email = @email ";
            cmd.Parameters.AddWithValue("@Email", oldemail);
            dr = cmd.ExecuteReader();
            int counter = 0; // Counter equal to listbox1 index
            // Loop to add the details to the listbox
            while (dr.Read())
            {
                IdByIndex.Add(counter, dr["ID"].ToString()); // Add the ID as val, key: listbox1index
                counter++;
                listBox1.Items.Add(dr["Name"].ToString());
                names.Add(dr["Name"].ToString());
            }
            con.Close();
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            // Query to get all the details of all the studies
            cmd.CommandText = "select * from  Research ";
            dr = cmd.ExecuteReader();
            counter = 0;
            // Loop to add to listbox2 only the studies which aren't linked to the researcher
            while (dr.Read())
            {

                if (!(this.names.Contains(dr["Name"].ToString())))
                {
                    listBox2.Items.Add(dr["Name"].ToString());
                    this.UidByIndex.Add(counter, dr["ID"].ToString());
                    counter++;
                }
            }
            con.Close();
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            //Query to get the relevant Researcher based on his email
            cmd.CommandText = "select * from Researcher Where Email = @mail";
            cmd.Parameters.AddWithValue("@mail", oldemail);
            dr = cmd.ExecuteReader();
            // Loop to add the Researcher details to the form
            while (dr.Read())
            {
                this.textBox1.Text = dr["Name"].ToString();
                this.textBox2.Text = dr["Phone"].ToString();
                this.textBox3.Text = dr["Email"].ToString();
                this.pictureBox1.ImageLocation = dr["photo"].ToString();
                this.richTextBox1.Text = dr["Description"].ToString();
            }
            this.Text = "Edit " + this.textBox1.Text; // Set the form title
            con.Close();
        }

        //Upload photo button
        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpeg;*.bmp;*.png;*.jpg)|*.jpeg;*.bmp;*.png;*.jpg"; // Allow only pictures format
            if (open.ShowDialog() == DialogResult.OK)
            {
                string newPhoto = open.FileName;
                string newpath = newPhoto.Replace("\\", "/"); // Flip the backslash 
                if (newPhoto != oldPhoto)
                {
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "Update Researcher SET Photo = @newPhoto Where Email = @Email"; // Update the photo in DB
                    cmd.Parameters.AddWithValue("@newPhoto", newpath);
                    cmd.Parameters.AddWithValue("@Email", oldemail);
                    dr = cmd.ExecuteReader();
                    con.Close();
                    this.pictureBox1.ImageLocation = newPhoto; // Update picturebox photo
                }

            }
        }

        //Edit Button
        private void button1_Click(object sender, EventArgs e)
        {
            //Set the fields editable
            this.textBox1.ReadOnly = false;
            this.textBox2.ReadOnly = false;
            this.textBox3.ReadOnly = false;
            this.richTextBox1.ReadOnly = false;
            //Save the values before edit
            oldname = this.textBox1.Text;
            oldphone = this.textBox2.Text;
            oldDescription = this.richTextBox1.Text;
            oldPhoto = this.pictureBox1.ImageLocation.ToString();
            //Display save button and hide all the others
            this.button2.Show();
            this.button5.Hide();
            this.button6.Hide();
            this.button7.Hide();
        }

        //Save button
        private void button2_Click(object sender, EventArgs e)
        {
            Boolean flag = false; // Flag that indicates on changes
            //Set all fields uneditable
            this.textBox1.ReadOnly = true;
            this.textBox2.ReadOnly = true;
            this.textBox3.ReadOnly = true;
            this.richTextBox1.ReadOnly = true;
            this.button5.Show();
  
            if (oldemail != this.textBox3.Text) // Compare email field after changes
            {
                if (this.Researcher.ContainsKey(this.textBox3.Text.ToString())) // Check if the email is used
                {
                    MessageBox.Show("The Email " + this.textBox3.Text + " is already used, please choose another one!");
                     this.textBox3.Text = oldemail;
                }
                else
                 {
                flag = true;
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "Update Researcher SET Email = @newEmail Where Email = @oldEmail"; // Update email query
                cmd.Parameters.AddWithValue("@newEmail", this.textBox3.Text);
                cmd.Parameters.AddWithValue("@oldEmail", oldemail);
                dr = cmd.ExecuteReader();
                Person temp = this.Researcher[oldemail];
                this.Researcher.Remove(oldemail);
                this.Researcher.Add(this.textBox3.Text, temp);
                oldemail = this.textBox3.Text;
                con.Close();
                }

            }

            if (oldname != this.textBox1.Text) // Compare name after changes
            {
                flag = true;
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "Update Researcher SET Name = @newName Where Email = @Email"; // Update the name in the DB
                cmd.Parameters.AddWithValue("@newName", this.textBox1.Text);
                cmd.Parameters.AddWithValue("@Email", oldemail);
                this.Researcher[this.textBox3.Text].Name = this.textBox1.Text;
                dr = cmd.ExecuteReader();
                con.Close();

            }
            if (oldphone != this.textBox2.Text) // Compare name after phone changes
            {
                flag = true;
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "Update Researcher SET Phone = @newPhone Where Email = @Email"; // Update the phone in the DB
                cmd.Parameters.AddWithValue("@newPhone", this.textBox2.Text);
                cmd.Parameters.AddWithValue("@Email", oldemail);
                dr = cmd.ExecuteReader();
                con.Close();

            }

            if (oldDescription != this.richTextBox1.Text.ToString()) // Compare description after phone changes
            {
                flag = true;
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "Update Researcher SET Description = @newDescription Where Email = @Email"; // Update the description in the DB
                cmd.Parameters.AddWithValue("@newDescription", this.richTextBox1.Text.ToString());
                cmd.Parameters.AddWithValue("@Email", oldemail);
                dr = cmd.ExecuteReader();
                con.Close();

            }
            if(flag)
            MessageBox.Show("The Details of " + this.textBox1.Text + " Updated Successfuly");
            // Hide the save button and display other buttons
            this.button2.Hide();
            this.button5.Show();
            this.button6.Show();
            this.button7.Show();
        }

        // Return to the main form button
        private void button3_Click(object sender, EventArgs e)
        {
            var form1 = new Form1();
            this.Hide();
            form1.Closed += (s, args) => this.Close();
            form1.StartPosition = FormStartPosition.Manual;
            form1.Location = this.Location;
            form1.Show();
        }

        // Delete button
        private void button5_Click(object sender, EventArgs e)
        {
            // Present a confirmation dialog
            var confirmResult = MessageBox.Show("Are you sure you want to delete this Researcher?",
                                    "Confirm Delete!",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == System.Windows.Forms.DialogResult.Yes)
            {
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "DELETE FROM Researcher Where Email= @email"; // Delete the researcher in the DB
                cmd.Parameters.AddWithValue("@email", oldemail);
                dr = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("The Researcher " + this.textBox1.Text + " Was Deleted Successfuly");
                var form1 = new Form1();
                this.Hide();
                form1.Closed += (s, args) => this.Close();
                form1.StartPosition = FormStartPosition.Manual;
                form1.Location = this.Location;
                form1.Show();
            }
        }

        // Unlink research button
        private void button6_Click(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedItem != null)
            {
                String selected = this.listBox1.SelectedItem.ToString(); // Get the selected research
                string ID = this.IdByIndex[this.listBox1.SelectedIndex]; // Get the relevant research ID
                var confirmResult = MessageBox.Show("Are you sure you want to remove " + this.textBox1.Text + " from the research " + this.listBox1.SelectedItem.ToString(),
                                       "Confirm Delete!",
                                       MessageBoxButtons.YesNo);
                if (confirmResult == System.Windows.Forms.DialogResult.Yes)
                {
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "DELETE FROM Research_Reasearches Where Email = @Email AND ID= @ID"; // Unlink researcher and study in the DB
                    cmd.Parameters.AddWithValue("@Email", oldemail);
                    cmd.Parameters.AddWithValue("@ID", ID);
                    dr = cmd.ExecuteReader();
                    con.Close();
                    MessageBox.Show(this.textBox1.Text + " Was Removed from the study Successfuly");
                    int selindex = this.listBox1.SelectedIndex; // Get the selected index
                    this.listBox1.Items.RemoveAt(selindex); // Remove the research from listbox1
                    this.IdByIndex.Remove(selindex); // Remove it from the dictionary based on the selection
                    Dictionary<int, string> temp = new Dictionary<int, string>();
                    // Loop to rebuild listbox1 Idbyindex after the changes
                    foreach (int item in this.IdByIndex.Keys)
                    {
                        if (item > selindex)
                        {
                        temp.Add(item - 1, this.IdByIndex[item]);
                        }
                        else
                        {
                        temp.Add(item, this.IdByIndex[item]);
                        }
                    }
                    this.IdByIndex = temp;
                    int index = this.listBox2.Items.Count; // Get the length of listbox2
                    this.UidByIndex.Add(index, ID); // Add the unlinked study to the unlinked studies dictionary by index
                    this.listBox2.Items.Add(selected); // Add the unlinked study to listbox2
                }

          }
       }
        
        // Present the relevant research after click
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedItem != null)
            {
                string ID = this.IdByIndex[this.listBox1.SelectedIndex]; // Get the selected research ID
                var form4 = new Form4(this.studies, ID, this.Researcher); // Create new edit research form based on the ID
                this.Hide();
                form4.Closed += (s, args) => this.Close();
                form4.StartPosition = FormStartPosition.Manual;
                form4.Location = this.Location;
                form4.Show();
            }
        }

        // Link research button
        private void button7_Click(object sender, EventArgs e)
        {
            if (this.listBox2.SelectedItem != null)
            {
                String selected = this.listBox2.SelectedItem.ToString(); // Get the selected research
                var confirmResult = MessageBox.Show("Are you sure you want to Add " + this.textBox1.Text + " to the research " + selected + " ?",
                                       "Confirm!",
                                       MessageBoxButtons.YesNo);
                if (confirmResult == System.Windows.Forms.DialogResult.Yes)
                {
                    string ID = this.UidByIndex[this.listBox2.SelectedIndex]; // Get the selected research ID
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "INSERT INTO Research_Reasearches (ID, Email) VALUES(@ID, @Email)"; // Update the changes into the DB
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Parameters.AddWithValue("@Email", this.textBox3.Text.ToString());
                    dr = cmd.ExecuteReader();
                    con.Close();
                    MessageBox.Show(this.textBox1.Text + " Was Added to the research " + selected + " Successfuly");
                    int selindex = this.listBox2.SelectedIndex; // Get the selected research index in listbox2
                    this.listBox2.Items.RemoveAt(selindex); // Remove the research from the list
                    this.UidByIndex.Remove(selindex); // Remove the research from the ID by index dictionary
                    Dictionary<int, string> temp = new Dictionary<int, string>();
                    // Loop to rebuild the dictionary after the removal 
                    foreach (int item in this.UidByIndex.Keys)
                    {
                        if (item > selindex)
                        {
                            temp.Add(item - 1, this.UidByIndex[item]);
                        }
                        else
                        {
                            temp.Add(item, this.UidByIndex[item]);
                        }
                    }
                    this.UidByIndex = temp;
                    int index = this.listBox1.Items.Count; // Get listbox1 length
                    this.IdByIndex.Add(index, ID); // Add the research to the listbox1 ID by index dictionary
                    this.listBox1.Items.Add(selected); // Add the research to listbox1
                }
            }
        }

        // Present the relevant research after click
        private void listBox2_DoubleClick(object sender, EventArgs e)
        {
            if (this.listBox2.SelectedItem != null)
            {
                string ID = this.UidByIndex[this.listBox2.SelectedIndex]; // Get the selected research ID
                var form4 = new Form4(this.studies, ID, this.Researcher);
                this.Hide();
                form4.Closed += (s, args) => this.Close();
                form4.StartPosition = FormStartPosition.Manual;
                form4.Location = this.Location;
                form4.Show();
            }
        }
    }
}
