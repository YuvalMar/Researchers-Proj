﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Windows;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-VUOJ1JB;Initial Catalog=Researches;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        String oldname = "";
        String oldDescription = "";
        Dictionary<string, string> studies = new Dictionary<string, string>(); // Dictionary of the studies, key: ID val: name
        Dictionary<string, Person> Researcher = new Dictionary<string, Person>(); // Dictionary of the Researchers key: Email val: Person
        Dictionary<int, string> UnEmailByIndex = new Dictionary<int, string>(); // Dictionary for listbox1 key: listboxindex val: name
        Dictionary<int, string> UpEmailByIndex = new Dictionary<int, string>(); // Dictionary for listbox2 key: listboxindex val: name
        public Form4(Dictionary<string, string> Researches, String ID, Dictionary<string, Person> Researcher )
        {
            this.studies = Researches;
            this.Researcher = Researcher;
            InitializeComponent();
            String id = ID;
            this.button2.Hide(); // Hide save button
            var namesList = new ArrayList(); // A list that contains all the researches names
            int counter = 0; // Counter equal to listbox1 index 
            if (id != null)
            {
                cmd = new SqlCommand();
                con.Open();
                cmd.Connection = con;
                // Query to get all the researches who belong to the relevant study
                cmd.CommandText = "select RS.Name,RS.Email from Researcher as RS INNER JOIN Research_Reasearches as RR  on RR.Email = RS.Email  INNER JOIN Research as R on RR.ID = R.ID Where R.ID = @ID ";
                cmd.Parameters.AddWithValue("@ID", id);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    UnEmailByIndex.Add(counter, dr["Email"].ToString()); // Map the emails by list index
                    counter++;
                    listBox1.Items.Add(dr["Name"].ToString());
                    namesList.Add(dr["Email"].ToString());
                }
                con.Close();
            }
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select * from Research Where ID = @ID"; // Get all the ID's
            cmd.Parameters.AddWithValue("@ID", id);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                this.textBox3.Text = dr["Name"].ToString();
                this.textBox2.Text = dr["ID"].ToString();
                this.richTextBox1.Text = dr["Description"].ToString();

            }
            this.Text = "Edit "+ this.textBox3.Text; // Set form title
            con.Close();
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select * from Researcher"; // Get all researcher details
            counter = 0;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (!(namesList.Contains(dr["Email"].ToString()))) // Add only researchers which doesn't belong to this study
                {
                    UpEmailByIndex.Add(counter, dr["Email"].ToString()); // Map by listbox2 index and email
                    counter++;
                    listBox2.Items.Add(dr["Name"].ToString());
                }
            }
            con.Close();
            this.textBox3.ReadOnly = true;
        }

        // Return to the main page button
        private void button3_Click(object sender, EventArgs e)
        {
            var form1 = new Form1();
            this.Hide();
            form1.Closed += (s, args) => this.Close();
            form1.StartPosition = FormStartPosition.Manual;
            form1.Location = this.Location;
            form1.Show();
        }

        // Delete button
        private void button5_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to delete this Study?",
                                 "Confirm Delete!",
                                 MessageBoxButtons.YesNo);
            if (confirmResult == System.Windows.Forms.DialogResult.Yes)
            {
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "DELETE FROM Research Where ID= @ID"; // Delete the research by ID in DB
                cmd.Parameters.AddWithValue("@ID", this.textBox2.Text.ToString());
                dr = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("The Study " + this.textBox3.Text + " Was Deleted Successfuly");
                var form1 = new Form1();
                this.Hide();
                form1.Closed += (s, args) => this.Close();
                form1.StartPosition = FormStartPosition.Manual;
                form1.Location = this.Location;
                form1.Show();
            }
        }

        //Edit button
        private void button1_Click(object sender, EventArgs e)
        {
            // Set the fields editable
            this.textBox3.ReadOnly = false;
            this.richTextBox1.ReadOnly = false;
            oldname = this.textBox3.Text;
            oldDescription = this.richTextBox1.Text;
            // Display Save button and hide Delete buttons
            this.button2.Show();
            this.button5.Hide();
            this.button6.Hide();
            this.button4.Hide();
        }

        // Save button
        private void button2_Click(object sender, EventArgs e)
        {
            Boolean flag = false; // Flag that indicates that changes were made
            this.textBox3.ReadOnly = true;
            this.richTextBox1.ReadOnly = true;
            this.button5.Show();

            if (oldname != this.textBox3.Text) // Compare email field after changes
            {
                flag = true;
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "Update Research SET Name = @newName Where ID = @ID"; // Update name in DB
                cmd.Parameters.AddWithValue("@newName", this.textBox3.Text);
                cmd.Parameters.AddWithValue("@ID", this.textBox2.Text);
                this.studies[this.textBox2.Text] = this.textBox3.Text;
                dr = cmd.ExecuteReader();
                con.Close();
            }

            if (oldDescription != this.richTextBox1.Text.ToString()) // Compare description field after changes
            {
                flag = true;
                cmd = new SqlCommand();
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "Update Research SET Description = @newDescription Where  ID = @ID"; // Update description in DB
                cmd.Parameters.AddWithValue("@newDescription", this.richTextBox1.Text.ToString());
                cmd.Parameters.AddWithValue("@ID", this.textBox2.Text);
                dr = cmd.ExecuteReader();
                con.Close();
            }
            if (flag)
                MessageBox.Show("The Details of " + this.textBox3.Text + " Updated Successfuly");
            // Hide Save button and display the others
            this.button2.Hide();
            this.button5.Show();
            this.button6.Show();
            this.button4.Show();

        }

        // Unlnk researcher button
        private void button6_Click(object sender, EventArgs e)
        {
            if(this.listBox1.SelectedItem!=null) { 
                String selected = this.listBox1.SelectedItem.ToString(); // Get the selected researcher name
                string Email = this.UnEmailByIndex[this.listBox1.SelectedIndex]; // Get the selected researcher email
                var confirmResult = MessageBox.Show("Are you sure you want to remove " + selected + " from the research " + this.textBox3.Text + " ?",
                                       "Confirm Delete!",
                                       MessageBoxButtons.YesNo);
                if (confirmResult == System.Windows.Forms.DialogResult.Yes)
                {
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "DELETE FROM Research_Reasearches Where Email = @Email AND ID= @ID"; // Delete query
                    cmd.Parameters.AddWithValue("@Email", Email);
                    cmd.Parameters.AddWithValue("@ID", this.textBox2.Text.ToString());
                    dr = cmd.ExecuteReader();
                    con.Close();
                    MessageBox.Show(selected + " Was Removed from the study " + this.textBox3.Text + " Successfuly");
                    int selindex = this.listBox1.SelectedIndex; // Get selected researcher index
                    this.listBox1.Items.RemoveAt(selindex); // Remove the name from listbox1
                    this.UnEmailByIndex.Remove(selindex); // Remove the deleted val from the dictionary
                    Dictionary<int, string> temp = new Dictionary<int, string>();
                    // Loop to rebuild the dictionary
                    foreach (int item in this.UnEmailByIndex.Keys)
                    {
                        if (item > selindex)
                        {
                            temp.Add(item - 1, this.UnEmailByIndex[item]);
                        }
                        else
                        {
                            temp.Add(item, this.UnEmailByIndex[item]);
                        }
                    }
                    this.UnEmailByIndex = temp;
                    int index = this.listBox2.Items.Count;
                    this.UpEmailByIndex.Add(index, Email); // Add the deleted researcher to listbox2 dictionary 
                    this.listBox2.Items.Add(selected); // Add the deleted researcher to listbox2
                }
            }
        }

        // Present the relevant researcher after click
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedItem != null)
            {
                string Email = this.UnEmailByIndex[this.listBox1.SelectedIndex]; // Get the selected researcher email
                var form2 = new Form2(Email, this.Researcher, this.studies);
                this.Hide();
                form2.Closed += (s, args) => this.Close();
                form2.StartPosition = FormStartPosition.Manual;
                form2.Location = this.Location;
                form2.Show();
            }
        }

        // Unlink researcher button
        private void button4_Click(object sender, EventArgs e)
        {
            if (this.listBox2.SelectedItem != null)
            {
                String selected = this.listBox2.SelectedItem.ToString(); // Get the selected researcher name
                var confirmResult = MessageBox.Show("Are you sure you want to Add " + selected + " to the research " + this.textBox3.Text + " ?",
                                       "Confirm!",
                                       MessageBoxButtons.YesNo);
                if (confirmResult == System.Windows.Forms.DialogResult.Yes)
                {
                    string Email = this.UpEmailByIndex[this.listBox2.SelectedIndex]; // Get the selected researcher email
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "INSERT INTO Research_Reasearches (ID, Email) VALUES(@ID, @Email)"; // Insert into DB query
                    cmd.Parameters.AddWithValue("@Email", Email);
                    cmd.Parameters.AddWithValue("@ID", this.textBox2.Text.ToString());
                    dr = cmd.ExecuteReader();
                    con.Close();
                    MessageBox.Show(selected + " Was Added to the study " + this.textBox3.Text + " Successfuly");
                    int selindex = this.listBox2.SelectedIndex; // Get the selected researcher Index in listbox2
                    this.listBox2.Items.RemoveAt(selindex); // Remove the researcher from listbox2
                    this.UpEmailByIndex.Remove(selindex); // Remove the researcher from the dictionary
                    Dictionary<int, string> temp = new Dictionary<int, string>();
                    // Loop to rebuild listbox2 id by index
                    foreach(int item in this.UpEmailByIndex.Keys)
                    {
                        if (item > selindex)
                        {
                            temp.Add(item - 1, this.UpEmailByIndex[item]);
                        }
                        else
                        {
                            temp.Add(item, this.UpEmailByIndex[item]);
                        }
                    }
                    this.UpEmailByIndex = temp;
                    int index = this.listBox1.Items.Count;
                    this.UnEmailByIndex.Add(index, Email); // Add the linked researcher to the linked researchers dictionary
                    this.listBox1.Items.Add(selected); // Add the linked researcher to listbox1
                }
            }
        }

        // Present the relevant researcher after click
        private void listBox2_DoubleClick(object sender, EventArgs e)
        {
            if (this.listBox2.SelectedItem != null)
            {
                string Email = this.UpEmailByIndex[this.listBox2.SelectedIndex]; // Get the selected researcher email
                var form2 = new Form2(Email, this.Researcher, this.studies);
                this.Hide();
                form2.Closed += (s, args) => this.Close();
                form2.StartPosition = FormStartPosition.Manual;
                form2.Location = this.Location;
                form2.Show();
            }
        }
    }
}
